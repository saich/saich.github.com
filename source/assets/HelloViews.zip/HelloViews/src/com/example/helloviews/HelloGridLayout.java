package com.example.helloviews;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

public class HelloGridLayout extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.grid);
		
		GridView gridView = (GridView)findViewById(R.id.gridview);
		gridView.setAdapter( new ImageAdapter(this) );
		
		gridView.setOnItemClickListener(new OnItemClickListener() {
			
			public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
				Toast.makeText(HelloGridLayout.this, "" + position, Toast.LENGTH_SHORT).show();
			}
		});
	}

}
