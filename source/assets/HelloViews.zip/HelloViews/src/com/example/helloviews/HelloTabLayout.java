package com.example.helloviews;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

public class HelloTabLayout extends TabActivity {
	
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.tabs);

	    Resources res = getResources();	// Resource object to get Drawables
	    TabHost tabHost = getTabHost();	// The activity TabHost
	    
	    // Alternatively, we can use the id to get the TabHost,
	    // but when not using getTabHost(), we need to explicitly 
	    // call the setup() function.
	    //TabHost tabHost = (TabHost)findViewById(R.id.tabhost);
	    //tabHost.setup();
	    TabHost.TabSpec spec;	// Reusable TabSpec for each tab
	    Intent intent;  		// Reusable Intent for each tab

	    // Create an Intent to launch an Activity for the tab (to be reused)
	    intent = new Intent().setClass(this, HelloLinearLayout.class);
	    
	    // TODO - having trouble in usage of setContent(id)

	    // Initialize a TabSpec for each tab and add it to the TabHostintent = new Intent().setClass(this, HelloLinearLayout.class);
	    spec = tabHost.newTabSpec("linear").setIndicator("Linear",
                res.getDrawable(R.drawable.ic_tabs))
            .setContent(intent);
	    tabHost.addTab(spec);

	    // Do the same for the other tabs
	    intent = new Intent().setClass(this, HelloRelativeLayout.class);
	    spec = tabHost.newTabSpec("relative").setIndicator("Relative",
	                      res.getDrawable(R.drawable.ic_tabs))
	                  .setContent(intent);
	    tabHost.addTab(spec);
	    
	    intent = new Intent().setClass(this, HelloTableLayout.class);
	    spec = tabHost.newTabSpec("table").setIndicator("Table",
                res.getDrawable(R.drawable.ic_tabs))
            .setContent(intent);
	    tabHost.addTab(spec);
	    
	    intent = new Intent().setClass(this, HelloGridLayout.class);
	    spec = tabHost.newTabSpec("grid").setIndicator("Grid",
                res.getDrawable(R.drawable.ic_tabs))
            .setContent(intent);
	    tabHost.addTab(spec);
	    
	    intent = new Intent().setClass(this, HelloListView.class);
	    spec = tabHost.newTabSpec("list").setIndicator("List",
                res.getDrawable(R.drawable.ic_tabs))
            .setContent(intent);
	    tabHost.addTab(spec);

	    //tabHost.setCurrentTab(0);
	}

}
